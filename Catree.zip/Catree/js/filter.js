function toggleFilter() {
    const panel = document.getElementById("filterPanel");
    panel.classList.toggle("active");
  }