function toggleInputForm() {
  const panel = document.getElementById("inputPanel");
  panel.classList.toggle("active");
}
